import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton
from PyQt6.QtWebEngineWidgets import QWebEngineView

class YouTubeApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YouTube App - Auto 2DIN")
        self.setGeometry(100, 100, 800, 480)  # tamaño típico 2 DIN

        layout = QVBoxLayout()

        # Entrada para URL o término de búsqueda
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Pega el enlace de YouTube o escribe un término de búsqueda")
        layout.addWidget(self.url_input)

        # Botón para cargar video
        self.load_btn = QPushButton("Cargar Video")
        self.load_btn.clicked.connect(self.load_video)
        layout.addWidget(self.load_btn)

        # Visor web para mostrar YouTube
        self.web_view = QWebEngineView()
        layout.addWidget(self.web_view)

        self.setLayout(layout)

    def load_video(self):
        url = self.url_input.text().strip()
        if not url:
            return
        # Si es un término de búsqueda simple, busca en YouTube
        if "youtube.com" not in url and "youtu.be" not in url:
            url = f"https://www.youtube.com/results?search_query={url.replace(' ', '+')}"
        # Si no es URL, lo toma como búsqueda y muestra resultados
        self.web_view.load(url)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = YouTubeApp()
    window.show()
    sys.exit(app.exec())
